# CommerceChat Shopify app

Links a Shopify store to CommerceChat (OAuth, product sync, chat widget).

## Recommended: serverless (no separate server)

CommerceChat deploys this app as a **Lambda** on your existing API. You do **not** need to run Node on a VPS.

### 1. Add Partner credentials

In `apps/api/.env` (or `.env.aws`):

```env
SHOPIFY_API_KEY=your_partner_api_key
SHOPIFY_API_SECRET=your_partner_api_secret
```

### 2. Deploy the API

```bash
npm run deploy:aws -- --env=dev --with-ingest-pipeline --with-ingest-step-functions
```

Your app base URL becomes:

```
https://YOUR-API.execute-api.us-east-1.amazonaws.com/shopify-app
```

### 3. Configure Shopify Partner Dashboard

| Field | Value |
|--------|--------|
| **App URL** | `https://YOUR-API.../shopify-app/auth` |
| **Allowed redirection URL(s)** | `https://YOUR-API.../shopify-app/auth/callback` |
| **Scopes** | `read_products`, `read_orders`, `write_script_tags` |
| **App uninstalled webhook** (optional) | `https://YOUR-API.../shopify-app/webhooks` |

### 4. Install on a store

```
https://YOUR-API.../shopify-app/auth?shop=STORE.myshopify.com
```

Paste your CommerceChat `pk_live_…` key when prompted.

### 5. Sync products

CommerceChat admin → **Knowledge → Shopify** → **Sync products**

---

## Alternative: self-hosted (zip download)

Use the zip from **Knowledge → Download Shopify app** if you want to run the app on your own server (Railway, VPS, ngrok for dev).

```bash
cd shopify-app
cp .env.example .env
npm install
npm run dev
```

Set `SHOPIFY_APP_URL` to your public HTTPS URL and `COMMERCECHAT_API_URL` to the CommerceChat API.

---

## Manual connect (no app)

Connect in CommerceChat admin with shop domain + Admin API token (`shpat_…`) and paste the widget embed in your theme.
